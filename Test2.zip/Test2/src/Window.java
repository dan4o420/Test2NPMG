import java.util.*;
import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.Container;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.Color;

public class Window extends JFrame{
	
	private String pickedcolor = "black";
	private JButton black = new JButton("black");
	private JButton red = new JButton("red");
	private JButton blue = new JButton("blue");
	private JButton green = new JButton("green");
	private JButton white = new JButton("white");
	private Container window;
	
	public Window() {
		window = getContentPane();
		window.setSize(600,600);
		window.setName("Triangle app");
		window.setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		window.setLayout(null);
	}
	

	
	
	
}